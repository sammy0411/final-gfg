import React, { useEffect, useState,useRef } from "react";
function Component({ profile, setProfile, ...props }) {
  return <h1 style={{color:"#7c7c7c"}}> <br/><br/>This is in development stage</h1>
}

export default Component;
