const methods=[
    {
        opttemperature:"inc",
        method:"Plastic coverage is a proven way to rapidly warm up your beds and increase the soil temperature, especially after a wet spell in winter.",
    },
    {
        opttemperature:"dec",
        method:" Mulches applied to the surface of a soil affect the amount of heat received and the way it is dissipated resulting in decrease of resultant soil temperature",
    },
    {
        opttemperature:"equal",
        method:"Your Soil Health is optimum just provide adequate amount of Water and Sunlight for the best productivity",
    }
];

export default methods;